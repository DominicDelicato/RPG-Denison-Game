import math
import pygame
import time
from random import randint 
pygame.init()

HEIGHT = 600
WIDTH = 800
screen=pygame.display.set_mode((WIDTH,HEIGHT))
BLACK = (  0,  0,  0)
GREEN = ( 34,177, 76)
WHITE = (255, 255, 255)
SC    = (255,228,191)
RED   = (255,  0,  0)
outline = 0

#----------------------------------------#
#    Human Properties                    #
#----------------------------------------#
hspeedX = 400
hspeedY = 300
humanX  = 400
humanY  = 300
infectedX = 100
infectedY = 100
infectedX2 = 100
infectedY2 = 100
infectedX =[0,infectedX2]
infectedY =[0,infectedY2]
gtext = ""
gmessage = "GAMEOVER"
ttext = ""
tmessage = ""
gtext_X = 800
gtext_Y = 600
ttext_X = 200
ttext_Y = 50
steps = 60
steps2 = steps/2
infected_speed = 100000
gamespeed = 100
show = False 
#----------------------------------------#
#    functions                           #
#----------------------------------------#
    #First step
        #Make the program draw the image [x]
def redraw_screen():
    show = False
    screen.fill(BLACK)
    screen.blit(humanPic, (humanX,humanY))
    screen.blit(infected, (infectedX,infectedY))
    screen.blit(infected, (infectedX2,infectedY2))
    ttext = tfont.render(tmessage, 1, WHITE)
    screen.blit(ttext,(ttext_X,ttext_Y))
    gtext = gfont.render(gmessage, 1, RED)
    screen.blit(gtext,(gtext_X,gtext_Y))
    pygame.display.update()
def get_size(image):
    rect = image.get_rect()
    size = math.sqrt(rect.width**2+rect.height**2)
    return size/2
def distance(x1,y1,x2,y2):
    dist = math.sqrt((x1-x2)**2+(y1-y2)**2)
    return dist


      



#----------------------------------------#
#       Main program                     #
#----------------------------------------#
BEGIN = 30
time = 0
tfont = pygame.font.SysFont("Courier New Bold",100)
gfont = pygame.font.SysFont("Courier New Bold",100)
humanPic = pygame.image.load("human.png")
infected = pygame.image.load("Zombie.png")
landscape = pygame.image.load("nuke town.png")
hsize=get_size(humanPic)
isize=get_size(infected)
pygame.mixer.music.load('Timber (8 Bit Remix Version) [Tribute to Ke$ha & Pitbull] - 8 Bit Universe Cover.mp3')  
pygame.mixer.music.set_volume(10)      
pygame.mixer.music.play(loops = -1)    
gulp = pygame.mixer.Sound("Sandstorm (8 Bit Remix Cover Version) [Tribute to Darude] - 8 Bit Universe.mp3") 
gulp.set_volume(9)
human = humanPic
infectedX = randint(1,300)
infectedY = randint(1,300)
inPlay = True
while inPlay:
    time = pygame.time.get_ticks()-BEGIN
    gametime = int(time)/1000
    tmessage = str(gametime)
# check for events
    pygame.event.get()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        inPlay = False
    #Second step
        #Make the image move up, down, left, right, turn in a 360
            #Second Step part 1
                #make the image move up
                #make it so the verticle part of the image is only able to move up
                    #by making the horizontal speed 0
                    #subtract the verticle part of the image by the verticle speed
    if keys[pygame.K_w]:
        humanY = humanY - 12
        humanY != gamespeed

    if keys[pygame.K_s]:
        humanY = humanY + 12
                #make the image move down
                #make it so the verticle part of the image is only able to move down
                    #by making the horizontal speed 0
                    #make the verticle part of the image equal to the verticle speed
    if keys[pygame.K_d]:
        humanX = humanX + 12
                #make the image move right
                #make is so the image can only move right
                    #by making the Verticle speed 0
                    #make the horizontal part of the image equal to the horizontal speed
    if keys[pygame.K_a]:
        humanX = humanX - 12
                #make the image move left
                #make it so the image can only move left
                    #by making the Verticle speed 0
                    #Make the horizontal part of the image subtract for the horizontal speed
    if screen.blit(infected, (infectedX2,infectedY2)):
        show = False 
    x = humanX - infectedX
    y = humanY - infectedY
    distanceX = x/steps
    distanceY = y/steps
    infectedX += distanceX 
    infectedY += distanceY

    x = humanX - infectedX2
    y = humanY - infectedY2
    distanceX = x/steps2
    distanceY = y/steps2
    infectedX2 += distanceX 
    infectedY2 += distanceY 
    # Make the two images not combine
        #Get the cordinates of the two images
            #Subtract the X for the other X image
            #Subtract the Y from the other image
    if infectedX == infectedX2:
        infectedX2 - infectedX
    if infectedY2 == infectedY:
        infectedY2 - infectedY
    print "Infected2",infectedX2,infectedY2,"infected",infectedX,infectedY
    if distance(infectedX,infectedY,humanX,humanY) < isize + hsize:
        inPlay = False
    if distance(infectedX2,infectedY2,humanX,humanY) < isize + hsize:
        inPlay = False
    # When the timer hits 10 seconds another infected spawn
    # When the timer hits 10 seconds there speed increases
    if gametime == 10:
        steps = steps - 1
    if gametime == 10:
        steps2 = steps2 - 1
    if gametime == 20:
        steps = steps - 1
    if gametime == 20:
        steps2 = steps2 - 1
        
    
    redraw_screen()
    pygame.time.delay(30)


pygame.quit()
