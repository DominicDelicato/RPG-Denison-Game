import pygame
from random import randint
from player_Class import Gondor
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED   = (255,  0,  0)
GREEN = (  0,255,  0)
BLUE  = (  0,  0,255)
HEIGHT = 600
WIDTH  = 800

player = Gondor(WIDTH)
class Zombie(object):
    def __init__(self):
        self.vitality = 100  #you can change the vitality
        self.attack = 0
        self.defense = 10
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(50,100)#you can chang zombie the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(50,80)#you can chang zombie drop the money
        return self.dropmoney
#------------------------------------------------------------------------#
class Slime(object):
    def __init__(self, WIDTH):
        self.vitality = 50  #you can change the vitality
        self.attack = 0
        self.defense = 0
        self.dropmoney = 0
        self.slimeX = randint(1,300)
        self.slimeY = randint(1,300)
        self.velocityX = 10
        self.velocityY = 10
        self.steps = 10

    def distance(x1,y1,x2,y2):
        dist = math.sqrt((x1-x2)**2+rect.height**2)
        return dist

    def draw(self, slimePic, screen):
        screen.blit(slimePic, (self.slimeX, self.slimeY))
        slimePic = pygame.transform.scale(slimePic, (10, 200))

    def move_Left(self):
        self.slimeX = self.slimeX + self.velocityX
        
    def move_Right(self):
        self.slimeX = self.slimeX -self.velocityX
        
    def move_Up(self):
        self.slimeY = self.slimeY + self.velocityY

    def move_Down(self):
        self.slimeY = self.slimeY - self.velocityY
        
    def move(self, other):
        x = other.playerX - self.slimeX
        y = other.playerY - self.slimeY
        distanceX = x/self.steps
        distanceY = y/self.steps
        self.slimeX += distanceX
        self.slimeY += distanceY

    def slimeAttack(self):
        self.attack = random.randint(10,15)#you can chang slime the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(10,20)#you can chang slime drop the money
        return self.dropmoney
#---------------------------------------------------------------------------#
class Assaddin(object):
    def __init__(self):
        self.vitality = 200  #you can change the vitality
        self.attack = 0
        self.defense = 20
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(100,150)#you can chang Assaddin the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(100,150)#you can chang Assaddin drop the money
        return self.dropmoney
#---------------------------------------------------------------------------#
class MagicSoldier(object):
    def __init__(self):
        self.vitality = 500  #you can change the vitality
        self.attack = 0
        self.defense = 50
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(200,350)#you can chang Magic Soldier the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(200,250)#you can chang Magic Soldier drop the money
        return self.dropmoney
#----------------------------------------------------------------------------#
class GiantMagic(object):
    def __init__(self):
        self.vitality = 800  #you can change the vitality
        self.attack = 0
        self.defense = 100
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(400,500)#you can chang Giant Magic the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(300,400)#you can chang Giant Magic drop the money
        return self.dropmoney


