
import pygame
pygame.init()
from random import randint
class FinalBoss(object):
    def __init__(self):
        self.bossX = 400
        self.bossY = 300
        self.bossR = 15
        self.speed = 10
        self.CLR = (255,255,255)
        self.bossDMG = (400,800,400,1000,1200)
        self.vitality = 5000
        self.DEF = 500
        self.directionSpeed = [[0,-self.speed],[0,+self.speed],[-self.speed,0],[self.speed,0]]
        self.directionList = ['up','down','left','right']
        self.direction = 'down'
        self.fireOn = False
        self.fyreX = self.bossX+10
        self.fyreY = self.bossY+30
        self.fyreR = 10
        self.steps = 20

    def draw(self, finalbossPic, fireball, screen):
        screen.blit(finalbossPic,(self.bossX,self.bossY))
        if self.fireOn == True:
            screen.blit(fireball,(fyreX,fyreY,20,0))
        

    def place(self,x, y):
        self.bossX = x
        self.bossY = y        
        
    def move(self,other):
        x = other.playerX - self.bossX
        y = other.playerY - self.bossY
        distanceX = x/self.steps
        distanceY = y/self.steps
        self.bossX += distanceX
        self.bossY += distanceY

    def fireBall(self):
        self.fireOn == True
            
        

        
        
        
        
        
        
   

  
    
      
        

    
