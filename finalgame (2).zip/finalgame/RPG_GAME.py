import pygame
import math
from random import randint
import random
from player_Class import Gondor
from MonsterClass import Slime
from walls import wall
from FinalBoss import FinalBoss

pygame.init()
HEIGHT = 600
WIDTH  = 1000
screen = pygame.display.set_mode((WIDTH,HEIGHT))
BLACK = (  0,  0,  0)
WHITE = (255,255,255)

def redraw_screen():
    screen.fill(BLACK)
    wall.draw(screen)
    screen.blit(wall.background, (wall.obX, wall.obY))
    player.draw(playerPic, screen)
    slime.draw(slimePic, screen)
    finalBoss.draw(finalbossPic, fireball, screen)
    pygame.display.update()

#-----------------------------#
# main program starts here    #
#-----------------------------#

#Player
playerPic = pygame.image.load("images/gongor0.png")
playerX = WIDTH/2
playerY = 300
playerYvelocity = 0
player = Gondor(WIDTH)

#Monsters
slimePic = pygame.image.load("images/slime2.png")
slimeX = randint(1,300)
slimeY = randint(1,300)
slime = Slime(WIDTH)

#map
wall = wall()
wall.place(-4000,150)

#FInal Boss
finalbossPic = pygame.image.load("images/dragon.png")
finalBoss = FinalBoss()
fireball = pygame.image.load("images/fireball.png")
inPlay = True

inPlay = True
while inPlay:
    #check for events
    pygame.event.get()
    keys = pygame.key.get_pressed()
    #act upon key events
    if keys[pygame.K_ESCAPE]:
        inPlay = False
    #monster move
    #Key movements
    if keys[pygame.K_RIGHT]:
        slime.move_Right()
        wall.goRight()
        playerPic = pygame.image.load("images/gongor3.png")
        
    elif keys[pygame.K_LEFT]:
        slime.move_Left()
        wall.goLeft()
        playerPic = pygame.image.load("images/gongor1.png")
        
    elif keys[pygame.K_UP]:
        slime.move_Up()
        wall.goUp()
        playerPic = pygame.image.load("images/gongor2.png")
        
    elif keys[pygame.K_DOWN]:
        slime.move_Down()
        wall.goDown()
        playerPic = pygame.image.load("images/gongor0.png")

    elif keys[pygame.K_f]:
        finalBoss.fireBall()

    if  screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR or \
        screen.get_at((player.playerX+player.playerW-25, player.playerY+player.playerH-30)) == wall.wallCLR or \
        screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR:
            print 'a'
            
    slime.move(player)
    finalBoss.move(player)



    redraw_screen()
    pygame.time.delay(1)
pygame.quit()
