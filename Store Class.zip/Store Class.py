####################
#store class
#Barry
###############
import pygame
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED   = (255,  0,  0)
GREEN = (  0,255,  0)
BLUE  = (  0,  0,255)
HEIGHT = 600
WIDTH  = 800

class Store(object):
    def __init__(self, money):
        self.storemoney = money
        self.arms = "No arms"
        self.armor = "No armor"
        self.GeneralPacks = 0
        self.CommonSyrup = 0
        self.AdvancedKits = 0
        self.AdcancedPotion = 0
        self.GodMedicine = 0
        self.TreatmentofSyrup = 0
        
        
        


    def __str__(self):
        return "You have $"+str(self.storemoney)+", Arms:"+str(self.arms)+", Armor:"+str(self.armor)+", General Packs * "+str(self.GeneralPacks)+", Common Syrup * "+str(self.CommonSyrup)+", Advanced Kits * "+str(self.AdvancedKits)+", God Medicine * "+str(self.GodMedicine)+", Adcanced Potion * "+str(self.AdcancedPotion)+", Treatment of Syrup * "+str(self.TreatmentofSyrup)


    def Arms(self,name):
        if name == "Feijian":
            self.storemoney -=50
            self.arms = name
        if name == "Dagger":
            self.storemoney -=120
            self.arms = name
        if name == "Sword":
            self.storemoney -=250
            self.arms = name
        if name == "shadowless Sword":
            self.storemoney -=400
            self.arms = name
        if name == "Soul Sword":
            self.storemoney -=550
            self.arms = name
        if name == "God Sword":
            self.storemoney -=800
            self.arms = name

    def Armor(self,name):
        if name == "Adventure Suit":
            self.storemoney -=150
            self.armor = name
        if name == "Iron Armor":
            self.storemoney -=300
            self.armor = name
        if name == "Hercules Helmet":
            self.storemoney -=600
            self.armor = name
        if name == "God's Armor":
            self.storemoney -=850
            self.armor = name

    def Props(self,name):
        if name == "General Packs":
            self.storemoney -=50
            self.GeneralPacks +=1
        if name == "Common Syrup":
            self.storemoney -=100
            self.CommonSyrup +=1
        if name == "Advanced Kits":
            self.storemoney -=350
            self.AdvancedKits +=1
        if name == "Advanced Potion":
            self.storemoney -=450
            self.AdcancedPotion +=1
        if name == "God Medicine":
            self.storemoney -=550
            self.GodMedicine +=1
        if name == "Treatment Of Syrup":
            self.storemoney -=200
            self.TreatmentofSyrup +=1


