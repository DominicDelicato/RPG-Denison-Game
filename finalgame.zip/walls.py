import pygame
import random
from random import randrange

WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED   = (255,  0,  0)

class wall(object):
    """ A Snake, consisting of circles-segments """
    def __init__(self):
        self.obX = 0
        self.obY = 7000
        self.obWIDTH = 800
        self.obHEIGHT = 4
        self.obSTEP = 5
        self.background = pygame.image.load("images/Whoisshe.png")
        self.background = pygame.transform.scale(self.background,(9000,5000))
        self.wallCLR = self.background.get_at((1,1))
    def draw(self, surface):
        pass
    def place(self, x, y,):
        self.obX = x
        self.obY = y
    def goLeft(self):
        self.obX = self.obX + self.obSTEP
    def goRight(self):
        self.obX = self.obX - self.obSTEP
    def goDown(self):
        self.obY = self.obY - self.obSTEP
    def goUp(self):
        self.obY = self.obY + self.obSTEP
    def move(self):
        self.oby = self.obY
class mapp(object):
    def __init__(self):
        self.obX = 0
        self.obY = 7000
        self.obWIDTH = 800
        self.obHEIGHT = 4
        self.obSTEP = 5
        self.background = pygame.image.load("images/Whoisshe.png")
        self.background = pygame.transform.scale(self.background,(0,0))
    def draw(self, surface):
        pass
    def place(self, x, y,):
        self.obX = x
        self.obY = y
    def mappbig(self):
        self.background = pygame.image.load("images/Whoisshe.png")
        self.background = pygame.transform.scale(self.background,(200,150))
