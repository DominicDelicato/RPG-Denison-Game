import pygame
from player_Class import Gondor

pygame.init()
HEIGHT = 600
WIDTH  = 1000
screen = pygame.display.set_mode((WIDTH,HEIGHT))
BLACK = (  0,  0,  0)
WHITE = (255,255,255)

def redraw_screen():
    screen.fill(BLACK)
    player.draw(playerPic, screen)
    pygame.display.update()
#-----------------------------#
# main program starts here    #
#-----------------------------#

#Player
playerPic = pygame.image.load("images/gongor0.png")
playerX = WIDTH/2
playerY = 300
playerYvelocity = 0
player = Gondor(WIDTH)
inPlay = True
while inPlay:
    #check for events
    pygame.event.get()
    keys = pygame.key.get_pressed()
    #act upon key events
    if keys[pygame.K_ESCAPE]:
        inPlay = False
    #Key movements
    if keys[pygame.K_RIGHT]:
        player.move_right()
        
    elif keys[pygame.K_LEFT]:
        player.move_left()

    elif keys[pygame.K_UP]:
        player.move_up()

    elif keys[pygame.K_DOWN]:
        player.move_down()



    redraw_screen()
    pygame.time.delay(30)
