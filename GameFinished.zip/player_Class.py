import pygame

pygame.init()

WHITE = (255,255,255)
BLACK = (  0,  0,  0)

class Gondor(object):
    """ The main Character """
    def __init__(self, WIDTH):
        self.playerXvelocity = 0
        self.playerYvelocity = 0
        self.playerX = WIDTH/2
        self.playerY = 300
        self.playerW = 55
        self.playerH = 100
        self.runSpeed = 10
        self.playerDir = "Right"

    def draw(self, playerPic, screen):
        screen.blit(playerPic,(self.playerX, self.playerY))

    def move_right(self):
        self.playerX = self.playerX + self.runSpeed
        
    def move_left(self):
        self.playerX = self.playerX - self.runSpeed

    def move_up(self):
        self.playerY = self.playerY - self.runSpeed

    def move_down(self):
        self.playerY = self.playerY + self.runSpeed
