import pygame
import math
from random import randint
import random
from player_Class import Gondor
from MonsterClass import Slime
from walls import wall

pygame.init()
HEIGHT = 600
WIDTH  = 1000
screen = pygame.display.set_mode((WIDTH,HEIGHT))
BLACK = (  0,  0,  0)
WHITE = (255,255,255)

def redraw_screen():
    screen.fill(BLACK)
    wall.draw(screen)
    screen.blit(wall.background, (wall.obX, wall.obY))
    player.draw(playerPic, screen)
    slime.draw(slimePic, screen)
    pygame.display.update()

#-----------------------------#
# main program starts here    #
#-----------------------------#

#Player
playerPic = pygame.image.load("images/gongor0.png")
playerX = WIDTH/2
playerY = 300
playerYvelocity = 0
player = Gondor(WIDTH)

#Monsters
slimePic = pygame.image.load("images/slime2.png")
slimeX = randint(1,300)
slimeY = randint(1,300)
slime = Slime(WIDTH)

#map
wall = wall()
wall.place(-4000,150)

inPlay = True
while inPlay:
    #check for events
    pygame.event.get()
    keys = pygame.key.get_pressed()
    #act upon key events
    if keys[pygame.K_ESCAPE]:
        inPlay = False
    #monster move
    #Key movements
    if keys[pygame.K_RIGHT]:
        player.move_right()
        wall.goRight()
        playerPic = pygame.image.load("images/gongor3.png")
        
    elif keys[pygame.K_LEFT]:
        player.move_left()
        wall.goLeft()
        playerPic = pygame.image.load("images/gongor1.png")
        
    elif keys[pygame.K_UP]:
        player.move_up()
        wall.goUp()
        playerPic = pygame.image.load("images/gongor2.png")
        
    elif keys[pygame.K_DOWN]:
        player.move_down()
        wall.goDown()
        playerPic = pygame.image.load("images/gongor0.png")

    if  screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR or \
        screen.get_at((player.playerX+player.playerW-25, player.playerY+player.playerH-30)) == wall.wallCLR or \
        screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR:
            print 'a'
            
    slime.move(player)



    redraw_screen()
    pygame.time.delay(1)
pygame.quit()
