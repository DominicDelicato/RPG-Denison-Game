####################
#Magic Soldier class
#Barry
###############

import pygame
import random
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED   = (255,  0,  0)
GREEN = (  0,255,  0)
BLUE  = (  0,  0,255)
HEIGHT = 600
WIDTH  = 800

class MagicSoldier(object):
    def __init__(self):
        self.vitality = 500  #you can change the vitality
        self.attack = 0
        self.defense = 50
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(200,350)#you can chang Magic Soldier the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(200,250)#you can chang Magic Soldier drop the money
        return self.dropmoney
