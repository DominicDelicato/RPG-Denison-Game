####################
#Assaddin class
#Barry
###############

import pygame
import random
WHITE = (255,255,255)
BLACK = (  0,  0,  0)
RED   = (255,  0,  0)
GREEN = (  0,255,  0)
BLUE  = (  0,  0,255)
HEIGHT = 600
WIDTH  = 800

class Assaddin(object):
    def __init__(self):
        self.vitality = 200  #you can change the vitality
        self.attack = 0
        self.defense = 20
        self.dropmoney = 0


    def slimeAttack(self):
        self.attack =random.randint(100,150)#you can chang Assaddin the attack
        return self.attack                

    def monsterInjured(self,hurt):  # if hurt biggest the bitality smile did
        hurt = hurt - self.defense
        self.vitality -= hurt
        return self.vitality

    def money():
        self.dropmoney =random.randint(100,150)#you can chang Assaddin drop the money
        return self.dropmoney
