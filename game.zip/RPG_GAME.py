import pygame
from player_Class import Gondor
from walls import wall

pygame.init()
HEIGHT = 600
WIDTH  = 1000
screen = pygame.display.set_mode((WIDTH,HEIGHT))
BLACK = (  0,  0,  0)
WHITE = (255,255,255)

def redraw_screen():
    screen.fill(BLACK)
    wall.draw(screen)
    screen.blit(wall.background,(wall.obX,wall.obY))
    player.draw(playerPic, screen)
    pygame.display.update()
#-----------------------------#
# main program starts here    #
#-----------------------------#

#Player
playerPic = pygame.image.load("images/gongor0.png")
playerYvelocity = 0
player = Gondor(WIDTH)
inPlay = True
wall = wall()
wall.place(-4000,150)
while inPlay:
    #check for events
    pygame.event.get()
    keys = pygame.key.get_pressed()
    #act upon key events
    if keys[pygame.K_ESCAPE]:
        inPlay = False
    #Key movements
    if keys[pygame.K_RIGHT]:
        wall.goRight()
        
    elif keys[pygame.K_LEFT]:
        wall.goLeft()

    elif keys[pygame.K_UP]:
        wall.goUp()

    elif keys[pygame.K_DOWN]: 
        wall.goDown()
        
    if  screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR or \
        screen.get_at((player.playerX+player.playerW-25, player.playerY+player.playerH-30)) == wall.wallCLR or \
        screen.get_at((player.playerX, player.playerY+10)) == wall.wallCLR:
            print 'a'


    redraw_screen()
    pygame.time.delay(1)
